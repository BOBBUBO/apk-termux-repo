#!/data/data/com.termux/files/usr/bin/bash
# apk-based bootstrap second stage
PREFIX=/data/data/com.termux/files/usr
SELF_DIR="$(cd "$(dirname "$0")" && pwd)"
# run once: atomic lock via symlink
ln -s . "$SELF_DIR/$(basename "$0").lock" 2>/dev/null || exit 0
# initialize the apk database
"$PREFIX/bin/apk" add --initdb >/dev/null 2>&1 || true
exit 0
